<?php
class Infusionsoft_ProductCategory extends Infusionsoft_Generated_ProductCategory{
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

