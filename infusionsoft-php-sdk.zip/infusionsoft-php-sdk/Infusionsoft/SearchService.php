<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Joey
 * Date: 6/25/11
 * Time: 4:29 PM
 * To change this template use File | Settings | File Templates.
 */
 
class Infusionsoft_SearchService extends Infusionsoft_SearchServiceBase {
    
}
