<?php
include('infusionsoft.php');

$contact = new Infusionsoft_Contact();

// $customFields = Infusionsoft_CustomFieldService::getCustomFields(new Infusionsoft_Contact());

/** @var Infusionsoft_DataFormField $customField */
// $customFieldsAsArray = array();
// foreach($customFields as $customField){
//     $customFieldsAsArray[] = '_' . $customField->Name;
// }

// $contact->addCustomFields($customFieldsAsArray);

// $contacts = Infusionsoft_DataService::queryWithOrderBy(new Infusionsoft_Contact(), array('Id' => '%'), '', 3, 1, array(''));
// echo "<pre>";
// var_dump($contacts);

$object = Infusionsoft_DataService::query(new Infusionsoft_Contact(), array('Id' => '4'));
echo "<pre>";
var_dump($object);
// $data =	Array
// 	        (
// 	            ['Address1Type'] => '',
// 	            ['Address2Street1'] => '',
// 	            ['Address2Street2'] => '',
// 	            ['Address2Type'] => '',
// 	            ['Address3Street1'] =>'', 
// 	            ['Address3Street2'] =>'', 
// 	            ['Address3Type'] => '',
// 	            ['Anniversary'] => '',
// 	            ['AssistantName'] =>'', 
// 	            ['AssistantPhone'] =>'', 
// 	            ['BillingInformation'] => 'axis',
// 	            ['Birthday'] => '',
// 	            ['City'] => 'Hyderabd',
// 	            ['City2'] => 'hyderabad',
// 	            ['City3'] => '',
// 	            ['Company'] => 'Newcompany',
// 	            ['AccountId'] => '2',
// 	            ['CompanyID'] => '2',
// 	            ['ContactNotes'] => ,
// 	            ['ContactType'] => 'Customer',
// 	            ['Country'] => 'India',
// 	            ['Country2'] => '',
// 	            ['Country3'] => '',
// 	            ['CreatedBy'] => '1',
// 	            ['DateCreated'] => '20171221T02:40:36',
// 	            ['Email'] => 'mubasherkhan22@gmail.com',
// 	            ['EmailAddress2'] => ,
// 	            ['EmailAddress3'] => 'abcd@gmail.com',
// 	            // [Fax1] => ,
// 	            // [Fax1Type] => 'Work',
// 	            // [Fax2] =>, 
// 	            // [Fax2Type] => 'Work',
// 	            // [FirstName] => 'Alii',
// 	            // [Groups] => ,
// 	            // [Id] => '4',
// 	            // [JobTitle] => 'devloper',
// 	            // [Language] => 'en',
// 	            // [LastName] => 'Maq',
// 	            // [LastUpdated] => '20171222T07:46:37',
// 	            // [LastUpdatedBy] => '-1',
// 	            // [Leadsource] => 'Direct Mail',
// 	            // [LeadSourceId] => '9',
// 	            // [MiddleName] => 'maqdoom',
// 	            // [Nickname] => 'mir',
// 	            // [OwnerID] => '1',
// 	            // [Password] => ,
// 	            // [Phone1] => '(953) 398-8485',
// 	            // [Phone1Ext] => ,
// 	            // [Phone1Type] => 'Work',
// 	            // [Phone2] => ,
// 	            // [Phone2Ext] =>, 
// 	            // [Phone2Type] => 'Work',
// 	            // [Phone3] => ,
// 	            // [Phone3Ext] => ,
// 	            // [Phone3Type] => 'Work',
// 	            // [Phone4] => ,
// 	            // [Phone4Ext] => ,
// 	            // [Phone4Type] => 'Work',
// 	            // [Phone5] => ,
// 	            // [Phone5Ext] =>, 
// 	            // [Phone5Type] => 'Work',
// 	            // [PostalCode] => '5000',
// 	            // [PostalCode2] => ,
// 	            // [PostalCode3] => ,
// 	            // [ReferralCode] => ,
// 	            // [SpouseName] => ,
// 	            // [State] => 'telangana',
// 	            // [State2] => ,
// 	            // [State3] => ,
// 	            // [StreetAddress1] => 'Address1',
// 	            // [StreetAddress2] => 'Address2',
// 	            // [Suffix] => ,
// 	            // [TimeZone] => 'Asia/Kolkata',
// 	            // [Title] => ,
// 	            // [Username] =>, 
// 	            // [Validated] => '0',
// 	            // [Website] => 'website.com',
// 	            // [ZipFour1] => '04',
// 	            // [ZipFour2] => ,
// 	            // [ZipFour3] => '05'
// 	        );

// //$out = Infusionsoft_DataService::add($data);
// print_r($data);