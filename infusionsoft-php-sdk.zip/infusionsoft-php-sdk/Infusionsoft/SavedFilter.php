<?php
class Infusionsoft_SavedFilter extends Infusionsoft_Generated_SavedFilter{
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

