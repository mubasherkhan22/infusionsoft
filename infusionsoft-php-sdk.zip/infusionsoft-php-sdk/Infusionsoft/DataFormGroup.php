<?php
class Infusionsoft_DataFormGroup extends Infusionsoft_Generated_DataFormGroup{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

