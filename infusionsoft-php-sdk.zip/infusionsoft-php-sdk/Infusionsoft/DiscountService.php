<?php
class Infusionsoft_DiscountService extends Infusionsoft_DiscountServiceBase{

}
