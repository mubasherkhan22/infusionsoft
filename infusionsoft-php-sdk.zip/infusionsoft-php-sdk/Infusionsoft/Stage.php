<?php
class Infusionsoft_Stage extends Infusionsoft_Generated_Stage{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

