<?php
class Infusionsoft_ContactGroupCategory extends Infusionsoft_Generated_ContactGroupCategory{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

