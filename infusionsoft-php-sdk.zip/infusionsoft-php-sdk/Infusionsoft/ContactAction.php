<?php
class Infusionsoft_ContactAction extends Infusionsoft_Generated_ContactAction{
    var $customFieldFormId = -5;
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

