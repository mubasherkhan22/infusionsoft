<?php
/**
 * @property String Id
 * @property String MaxLinked
 * @property String TypeName
 */
class Infusionsoft_LinkedContactType extends Infusionsoft_Generated_LinkedContactType{
    
}
