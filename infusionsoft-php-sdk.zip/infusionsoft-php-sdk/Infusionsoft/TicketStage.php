<?php
class Infusionsoft_TicketStage extends Infusionsoft_Generated_TicketStage{	
    public function __construct($id = null, $app = null){
    	parent::__construct($id, $app);    	    	
    }
}

