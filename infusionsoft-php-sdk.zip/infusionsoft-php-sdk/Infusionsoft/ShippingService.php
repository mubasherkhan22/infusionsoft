<?php
class Infusionsoft_ShippingService extends Infusionsoft_ShippingServiceBase{

}
