<?php
class Infusionsoft_APIEmailService extends Infusionsoft_APIEmailServiceBase{

}