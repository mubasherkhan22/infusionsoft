<?php
require_once 'vendor/autoload.php';
//require_once('Infusionsoft/infusionsoft.php');

$infusionsoft = new Infusionsoft\Infusionsoft(array(
    'clientId'     => 'XXXXXXXXXXXXXXXXXXXXXX',
    'clientSecret' => 'XXXXXXXXX',
    'redirectUri'  => 'http://localhost/infusion21/test.php',
));
 echo '<a href="' . $infusionsoft->getAuthorizationUrl() . '">Click here to authorize</a>';
//print_r($_GET);
//var_dump($_GET);
print_r($infusionsoft);
//$contactId = 4;
//$selectedFields = array('Email', 'FirstName');
//$email = 'mubasher22@gmail.com';
//$returnFields = array('Email', 'FirstName', 'LastName', '_myCustomField');
$infusionsoft->requestAccessToken($_GET['code']);
echo "<pre>";
var_dump($infusionsoft);
 $email1         = new \stdClass;
    $email1->field  = 'EMAIL1';
    $email1->email  = 'mir@example.com';
    $phone1         = new \stdClass;
    $phone1->field  = 'PHONE1';
    $phone1->number = '741852369';
    $contact        = ['given_name'      => 'mir',
                       'family_name'     => 'mir',
                       'email_addresses' => [$email1],
                       'phone_numbers'   => [$phone1]
    ];
// $contact = array(
// 	'email_addresses' => array(
// 		array(
// 			'email' => 'test@test.com',
// 			'field' => 'EMAIL1'
// 		)
// 	),
// 	'FirstName' => 'John',
// 	'LastName' => 'Doe',
// 	'phone_numbers' => array(
// 		array(
// 			'field' => 'PHONE1', 
// 			'number' => '123-123-1234'
// 		)
// 	)
// );
//$contact = ['FirstName' => 'John', 'LastName' => 'Doe', 'Email' => [$email]];
?>
<!-- <form  method="post" action="">
Name: <input type="text" name="name">
Family Name <input type="text" name="family">
Email <input type="email" name="email">
Phone <input type="number" name="phone">
<input type="submit" name="submit"> -->
<?php
//print_r($_POST);
// if(isset($_POST['submit']))
// {
//    //display();
//     print_r($_POST);
//     $email1         = new \stdClass;
//     $email1->field  = 'EMAIL1';
//     $email1->email  = $_POST['email'];
// $phone1         = new \stdClass;
//     $phone1->field  = 'PHONE1';
//     $phone1->number = $_POST['phone'];
//     $contact        = ['given_name'      => $_POST['name'],
//                        'family_name'     => $_POST['family'],
//                        'email_addresses' => [$email1],
//                        'phone_numbers'   => [$phone1]
//     ];
//    $cont = $infusionsoft->contacts()->create($contact);
// } 
// function display(){
//   try {
    
//         //$contact = ['FirstName' => 'John', 'LastName' => 'Doe', 'Email' => [$email]];
//         //$contact = json_decode($contact);
//         //return $infusionsoft->contacts()->create($contact);
//     print_r($_POST);
//     $email1         = new \stdClass;
//     $email1->field  = 'EMAIL1';
//     $email1->email  = $_POST['email'];
// $phone1         = new \stdClass;
//     $phone1->field  = 'PHONE1';
//     $phone1->number = $_POST['phone'];
//     $contact        = ['given_name'      => $_POST['name'],
//                        'family_name'     => $_POST['family'],
//                        'email_addresses' => [$email1],
//                        'phone_numbers'   => [$phone1]
//     ];
//   print_r($contact);
//  $cont = $infusionsoft->contacts()->create($contact);
// } catch (Exception $e) {
//   var_dump($e);
//       return;
// }
// }

try {
		
		    //$contact = ['FirstName' => 'John', 'LastName' => 'Doe', 'Email' => [$email]];
		    //$contact = json_decode($contact);
		    //return $infusionsoft->contacts()->create($contact);
	
	$cont = $infusionsoft->contacts()->create($contact);
} catch (Exception $e) {
	var_dump($e);
 			return;
}
//$cont = $infusionsoft->contacts()->add($contact);
//print_r($cont);
//$infusionsoft->refreshAccessToken();
// print_r($infusionsoft);
//$conDat = $infusionsoft->loadCon(4, $returnFields);
// $contact = $infusionsoft->contacts()->findByEmail($email, $selectedFields);
// try {
// 	$contact = $infusionsoft->contacts()->load($contactId, $selectedFields);
// } catch (Exception $e) {
// 			echo htmlspecialchars($e);
// 			var_dump($e);
// 			return;
// }
// $contact = $infusionsoft->contacts()->load($contactId, $selectedFields);
var_dump($contact);
renderObjectForm($contact);


// $invoices = getInvoicesForContact('4');
// print_r($invoices);

//  if(isset($_SESSION['appHostName'])){		
// 	Infusionsoft_AppPool::addApp(new Infusionsoft_App($_SESSION['appHostName'], $_SESSION['appKey'], $_SESSION['appPort']));
// 	echo "string";
// }
// print_r($_SESSION);